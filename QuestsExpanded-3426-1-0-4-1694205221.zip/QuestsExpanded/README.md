# Changes

1. Removes the initial starting quest and replaces it with just the marker to the trader.

2. Trader quests will reset 2 days instead of every 3 days

3. Adds 150+ quests